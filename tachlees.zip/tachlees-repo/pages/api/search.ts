// app/api/search/route.ts
// Production-grade price search API endpoint

import { NextRequest, NextResponse } from "next/server";
import type {
  PriceSearchRequest,
  PriceSearchResponse,
  NormalizedPrice,
  ApiResponse,
} from "@/lib/types";
import { CategoryType, ValidationError, NotFoundError } from "@/lib/types";
import { PriceEngine, calculateDistance } from "@/lib/engines/price-engine";
import { prisma } from "@/lib/db";
import { redis } from "@/lib/redis";
import { CACHE_KEYS, CACHE_TTL } from "@/lib/types";

/**
 * POST /api/search
 * Search and compare prices with advanced filtering
 * 
 * Query params: category, city, radius_km, sort_by, limit, offset
 * Body (optional): category_specific_params (monthly_consumption, vehicle_category, etc.)
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  const requestId = crypto.randomUUID();
  const startTime = Date.now();

  try {
    // ========================================================================
    // 1. PARSE & VALIDATE REQUEST
    // ========================================================================

    const body = await request.json();
    const searchReq: PriceSearchRequest = {
      category: body.category || CategoryType.CELLULAR,
      service_query: body.service_query,
      city: body.city,
      latitude: body.latitude,
      longitude: body.longitude,
      radius_km: body.radius_km || 25, // Default 25km for local services
      params: body.params,
      verification_types: body.verification_types,
      min_confidence_score: body.min_confidence_score ?? 0.3,
      exclude_flagged: body.exclude_flagged !== false,
      sort_by: body.sort_by || "price_asc",
      limit: Math.min(body.limit || 50, 200), // Max 200
      offset: body.offset || 0,
    };

    // Validate category
    if (!Object.values(CategoryType).includes(searchReq.category)) {
      throw new ValidationError("Invalid category", {
        provided: searchReq.category,
        valid: Object.values(CategoryType),
      });
    }

    // ========================================================================
    // 2. CHECK CACHE
    // ========================================================================

    const cacheKey = CACHE_KEYS.SEARCH(
      searchReq.category,
      JSON.stringify({
        city: searchReq.city,
        params: searchReq.params,
        sort: searchReq.sort_by,
      })
    );

    const cachedResult = await redis.get(cacheKey);
    if (cachedResult) {
      return NextResponse.json({
        success: true,
        data: JSON.parse(cachedResult),
        cached: true,
        request_id: requestId,
        timestamp: new Date().toISOString(),
      } as ApiResponse<PriceSearchResponse>);
    }

    // ========================================================================
    // 3. QUERY DATABASE
    // ========================================================================

    // Build WHERE clause
    const whereClause: any = {
      category: { type: searchReq.category },
      is_active: true,
      status: {
        in: searchReq.exclude_flagged
          ? ["VERIFIED", "UNVERIFIED", "PENDING"]
          : ["VERIFIED", "UNVERIFIED", "PENDING", "FLAGGED"],
      },
      confidence_score: { gte: searchReq.min_confidence_score },
    };

    // Service filtering (free-text search on name)
    if (searchReq.service_query) {
      whereClause.service = {
        name: { contains: searchReq.service_query, mode: "insensitive" },
      };
    }

    // Location filtering (for local services)
    if (searchReq.city) {
      whereClause.vendor = {
        city: { contains: searchReq.city, mode: "insensitive" },
      };
    }

    // Verification filtering
    if (searchReq.verification_types && searchReq.verification_types.length > 0) {
      whereClause.verification = { in: searchReq.verification_types };
    }

    // Fetch raw prices with relations
    const rawPrices = await prisma.price.findMany({
      where: whereClause,
      include: {
        vendor: true,
        service: true,
        branch: true,
      },
      take: searchReq.limit,
      skip: searchReq.offset,
    });

    const totalCount = await prisma.price.count({ where: whereClause });

    // ========================================================================
    // 4. NORMALIZE PRICES
    // ========================================================================

    const normalized: NormalizedPrice[] = await Promise.all(
      rawPrices.map((price) =>
        PriceEngine.normalizePrice(price, price.vendor, price.service, {
          latitude: searchReq.latitude,
          longitude: searchReq.longitude,
          monthly_consumption: searchReq.params?.monthly_kwh_consumption,
          vehicle_category: searchReq.params?.vehicle_category,
        })
      )
    );

    // ========================================================================
    // 5. APPLY GEOLOCATION (for branch-based local services)
    // ========================================================================

    if (searchReq.latitude && searchReq.longitude && searchReq.radius_km) {
      const filtered = normalized.filter((price) => {
        if (!price.branch) return true; // Keep non-branch prices

        const distance = calculateDistance(
          searchReq.latitude!,
          searchReq.longitude!,
          price.branch.latitude,
          price.branch.longitude
        );

        if (distance > searchReq.radius_km!) {
          return false; // Outside radius
        }

        price.branch.distance_km = Math.round(distance * 10) / 10; // Round to 1 decimal
        return true;
      });

      normalized.length = 0;
      normalized.push(...filtered);
    }

    // ========================================================================
    // 6. SORT RESULTS
    // ========================================================================

    let sorted: NormalizedPrice[];

    switch (searchReq.sort_by) {
      case "price_asc":
        // Sort by cheapest, boosting high-confidence items
        sorted = PriceEngine.rankPrices(normalized);
        break;

      case "price_desc":
        sorted = [...normalized].sort(
          (a, b) => b.total_12_month_cost - a.total_12_month_cost
        );
        break;

      case "rating":
        sorted = [...normalized].sort((a, b) => {
          const rating_diff = (b.rating_avg || 0) - (a.rating_avg || 0);
          if (rating_diff !== 0) return rating_diff;
          // Tiebreaker: cheaper price
          return a.total_12_month_cost - b.total_12_month_cost;
        });
        break;

      case "distance":
        if (searchReq.latitude && searchReq.longitude) {
          sorted = [...normalized].sort((a, b) => {
            const distA = a.branch?.distance_km ?? 999;
            const distB = b.branch?.distance_km ?? 999;
            return distA - distB;
          });
        } else {
          sorted = normalized;
        }
        break;

      case "confidence":
        sorted = [...normalized].sort(
          (a, b) => b.confidence_score - a.confidence_score
        );
        break;

      default:
        sorted = PriceEngine.rankPrices(normalized);
    }

    // ========================================================================
    // 7. BUILD RESPONSE METADATA
    // ========================================================================

    const prices_numbers = normalized.map((p) => p.total_12_month_cost);
    const average_price =
      prices_numbers.length > 0
        ? prices_numbers.reduce((a, b) => a + b, 0) / prices_numbers.length
        : 0;
    const sorted_prices = prices_numbers.sort((a, b) => a - b);
    const median_price =
      sorted_prices.length % 2 === 0
        ? (sorted_prices[sorted_prices.length / 2 - 1] +
            sorted_prices[sorted_prices.length / 2]) /
          2
        : sorted_prices[Math.floor(sorted_prices.length / 2)];

    const response: PriceSearchResponse = {
      results: sorted,
      total_count: totalCount,
      total_pages: Math.ceil(totalCount / searchReq.limit!),
      current_page: Math.floor(searchReq.offset! / searchReq.limit!) + 1,
      metadata: {
        search_time_ms: Date.now() - startTime,
        average_price,
        median_price,
        price_range: {
          min: prices_numbers.length > 0 ? Math.min(...prices_numbers) : 0,
          max: prices_numbers.length > 0 ? Math.max(...prices_numbers) : 0,
        },
        cheapest_vendor: sorted[0]?.vendorId,
        top_vendor_by_rating:
          [...normalized]
            .sort((a, b) => (b.rating_avg || 0) - (a.rating_avg || 0))
            .at(0)?.vendorId,
      },
    };

    // ========================================================================
    // 8. CACHE & RETURN
    // ========================================================================

    // Cache for 5 minutes
    await redis.setex(
      cacheKey,
      CACHE_TTL.SEARCH_RESULTS,
      JSON.stringify(response)
    );

    return NextResponse.json(
      {
        success: true,
        data: response,
        request_id: requestId,
        timestamp: new Date().toISOString(),
      } as ApiResponse<PriceSearchResponse>,
      { status: 200 }
    );
  } catch (error) {
    // ========================================================================
    // ERROR HANDLING
    // ========================================================================

    console.error(`[Search API] Error (${requestId}):`, error);

    if (error instanceof ValidationError) {
      return NextResponse.json(
        {
          success: false,
          error: {
            code: error.code,
            message: error.message,
            details: error.details,
          },
          request_id: requestId,
          timestamp: new Date().toISOString(),
        } as ApiResponse<null>,
        { status: error.statusCode }
      );
    }

    if (error instanceof NotFoundError) {
      return NextResponse.json(
        {
          success: false,
          error: {
            code: error.code,
            message: error.message,
          },
          request_id: requestId,
          timestamp: new Date().toISOString(),
        } as ApiResponse<null>,
        { status: 404 }
      );
    }

    // Generic error
    return NextResponse.json(
      {
        success: false,
        error: {
          code: "INTERNAL_SERVER_ERROR",
          message:
            error instanceof Error ? error.message : "Unknown error occurred",
        },
        request_id: requestId,
        timestamp: new Date().toISOString(),
      } as ApiResponse<null>,
      { status: 500 }
    );
  }
}

/**
 * GET /api/search
 * Alternative: query string based search (for bookmarking, sharing)
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  const searchParams = request.nextUrl.searchParams;

  const body = {
    category: searchParams.get("category"),
    service_query: searchParams.get("query"),
    city: searchParams.get("city"),
    latitude: searchParams.get("lat") ? parseFloat(searchParams.get("lat")!) : undefined,
    longitude: searchParams.get("lng") ? parseFloat(searchParams.get("lng")!) : undefined,
    radius_km: searchParams.get("radius") ? parseFloat(searchParams.get("radius")!) : undefined,
    sort_by: searchParams.get("sort"),
    limit: searchParams.get("limit") ? parseInt(searchParams.get("limit")!) : 50,
    offset: searchParams.get("page") ? (parseInt(searchParams.get("page")!) - 1) * 50 : 0,
    params: searchParams.get("params") ? JSON.parse(searchParams.get("params")!) : undefined,
  };

  const req = new NextRequest(request, { body: JSON.stringify(body) });
  return POST(req);
}
