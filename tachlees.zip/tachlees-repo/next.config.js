/** @type {import('next').NextConfig} */

const nextConfig = {
  // עברית
  i18n: {
    locales: ['he'],
    defaultLocale: 'he',
  },
  
  // ביצועים
  swcMinify: true,
  compress: true,
  
  // תמונות
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },
  
  // Environment
  env: {
    NEXT_PUBLIC_APP_NAME: 'תאכלס - הכי זול בארץ',
  },

  // Redirects & Rewrites
  async redirects() {
    return []
  },

  async rewrites() {
    return []
  },

  // Headers
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          {
            key: 'Access-Control-Allow-Credentials',
            value: 'true',
          },
          {
            key: 'Access-Control-Allow-Origin',
            value: '*',
          },
          {
            key: 'Access-Control-Allow-Methods',
            value: 'GET,DELETE,PATCH,POST,PUT',
          },
          {
            key: 'Access-Control-Allow-Headers',
            value: 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version',
          },
        ],
      },
    ]
  },

  // Logging
  logging: {
    fetches: {
      fullUrl: true,
    },
  },

  // TypeScript
  typescript: {
    tsconfigPath: './tsconfig.json',
  },
}

module.exports = nextConfig
