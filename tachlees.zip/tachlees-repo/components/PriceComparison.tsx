// components/PriceComparison.tsx
// Production-grade price search and comparison UI component for תאכלס

"use client";

import React, { useState, useCallback, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import type {
  PriceSearchRequest,
  PriceSearchResponse,
  NormalizedPrice,
  CategoryType,
  CategorySpecificParams,
} from "@/lib/types";
import { VerificationType } from "@/lib/types";

// ============================================================================
// COMPONENT TYPES
// ============================================================================

interface SearchFilters {
  category: CategoryType;
  city?: string;
  params?: CategorySpecificParams;
  verification_types?: VerificationType[];
  sort_by: "price_asc" | "price_desc" | "rating" | "distance" | "confidence";
  exclude_flagged: boolean;
}

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export function PriceComparison({ defaultCategory }: { defaultCategory: CategoryType }) {
  // =======================
  // STATE
  // =======================

  const [filters, setFilters] = useState<SearchFilters>({
    category: defaultCategory,
    sort_by: "price_asc",
    exclude_flagged: true,
  });

  const [page, setPage] = useState(1);
  const limit = 20;

  // =======================
  // FETCH DATA
  // =======================

  const { data, isLoading, error } = useQuery({
    queryKey: [
      "prices",
      filters.category,
      filters.city,
      filters.params,
      filters.sort_by,
      page,
    ],
    queryFn: async (): Promise<PriceSearchResponse> => {
      const searchReq: PriceSearchRequest = {
        category: filters.category,
        city: filters.city,
        params: filters.params,
        verification_types: filters.verification_types,
        sort_by: filters.sort_by,
        limit,
        offset: (page - 1) * limit,
        exclude_flagged: filters.exclude_flagged,
      };

      const response = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(searchReq),
      });

      if (!response.ok) {
        throw new Error(`Search failed: ${response.statusText}`);
      }

      const json = await response.json();
      return json.data;
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // =======================
  // HANDLERS
  // =======================

  const handleFilterChange = useCallback(
    (newFilters: Partial<SearchFilters>) => {
      setFilters((prev) => ({ ...prev, ...newFilters }));
      setPage(1); // Reset pagination
    },
    []
  );

  const handleCityChange = useCallback((city: string) => {
    handleFilterChange({ city });
  }, [handleFilterChange]);

  const handleSortChange = useCallback(
    (sort: SearchFilters["sort_by"]) => {
      handleFilterChange({ sort_by: sort });
    },
    [handleFilterChange]
  );

  // =======================
  // COMPUTED VALUES
  // =======================

  const totalPages = data?.total_pages ?? 1;
  const searchTimeMs = data?.metadata.search_time_ms ?? 0;

  // =======================
  // RENDER
  // =======================

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* HEADER */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            תאכלס - הכי זול בארץ
          </h1>
          <p className="text-gray-600 text-lg">
            השווה מחירים של חברות חשמל, סלולר, אינטרנט, גז וביטוח רכב
          </p>
        </div>

        {/* FILTER PANEL */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* City Filter */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                עיר/אזור
              </label>
              <input
                type="text"
                placeholder="תל אביב, חיפה, ירושלים..."
                value={filters.city || ""}
                onChange={(e) => handleCityChange(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Sorting */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                מיין לפי
              </label>
              <select
                value={filters.sort_by}
                onChange={(e) => handleSortChange(e.target.value as any)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="price_asc">הזול ביותר</option>
                <option value="price_desc">היקר ביותר</option>
                <option value="rating">דירוג גבוה ביותר</option>
                <option value="distance">קרוב ביותר</option>
                <option value="confidence">אמינות גבוהה</option>
              </select>
            </div>

            {/* Exclude Flagged */}
            <div className="flex items-end">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={filters.exclude_flagged}
                  onChange={(e) =>
                    handleFilterChange({ exclude_flagged: e.target.checked })
                  }
                  className="w-5 h-5 text-blue-600 rounded"
                />
                <span className="text-sm font-medium text-gray-700">
                  הסתר מחירים חריגים
                </span>
              </label>
            </div>

            {/* Search Stats */}
            <div className="flex items-end">
              {isLoading ? (
                <div className="text-sm text-gray-500">
                  <span className="animate-pulse">חיפוש...</span>
                </div>
              ) : (
                <div className="text-sm text-gray-500">
                  נמצאו {data?.total_count ?? 0} תוצאות
                  {searchTimeMs > 0 && ` (${searchTimeMs}ms)`}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ERROR STATE */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-8">
            <p className="text-red-800 font-semibold">שגיאה בחיפוש</p>
            <p className="text-red-700 text-sm">
              {error instanceof Error ? error.message : "קרתה שגיאה לא צפויה"}
            </p>
          </div>
        )}

        {/* RESULTS TABLE */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          {isLoading ? (
            <div className="p-12 text-center">
              <div className="inline-block">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              </div>
              <p className="mt-4 text-gray-600 font-medium">טוען תוצאות...</p>
            </div>
          ) : data && data.results.length > 0 ? (
            <>
              <PriceTable
                prices={data.results}
                metadata={data.metadata}
                category={filters.category}
              />

              {/* PAGINATION */}
              <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  עמוד {page} מתוך {totalPages} • סה"כ {data.total_count} תוצאות
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page === 1}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    ← הקודם
                  </button>

                  <div className="flex items-center gap-1">
                    {Array.from({ length: Math.min(totalPages, 5) }).map(
                      (_, i) => {
                        const pageNum = i + 1;
                        return (
                          <button
                            key={pageNum}
                            onClick={() => setPage(pageNum)}
                            className={`px-3 py-2 rounded-lg text-sm font-medium ${
                              page === pageNum
                                ? "bg-blue-600 text-white"
                                : "border border-gray-300 text-gray-700 hover:bg-gray-50"
                            }`}
                          >
                            {pageNum}
                          </button>
                        );
                      }
                    )}
                  </div>

                  <button
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    הבא →
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="p-12 text-center">
              <div className="text-gray-400 text-6xl mb-4">🔍</div>
              <p className="text-gray-700 font-semibold mb-2">אין תוצאות</p>
              <p className="text-gray-600 text-sm">
                נסה לשנות את הפילטרים שלך והנסה שוב
              </p>
            </div>
          )}
        </div>

        {/* FOOTER INFO */}
        {data && (
          <div className="mt-8 bg-blue-50 rounded-lg p-6 border border-blue-200">
            <h3 className="font-semibold text-gray-900 mb-3">💡 סיכום הסקר</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-gray-600">מחיר ממוצע</p>
                <p className="text-2xl font-bold text-blue-600">
                  ₪{Math.round(data.metadata.average_price)}
                </p>
              </div>
              <div>
                <p className="text-gray-600">מחיר חציוני</p>
                <p className="text-2xl font-bold text-blue-600">
                  ₪{Math.round(data.metadata.median_price)}
                </p>
              </div>
              <div>
                <p className="text-gray-600">הזול ביותר</p>
                <p className="text-2xl font-bold text-green-600">
                  ₪{Math.round(data.metadata.price_range.min)}
                </p>
              </div>
              <div>
                <p className="text-gray-600">היקר ביותר</p>
                <p className="text-2xl font-bold text-red-600">
                  ₪{Math.round(data.metadata.price_range.max)}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// PRICE TABLE COMPONENT
// ============================================================================

interface PriceTableProps {
  prices: NormalizedPrice[];
  metadata: any;
  category: CategoryType;
}

function PriceTable({ prices, metadata, category }: PriceTableProps) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-gray-50 border-b border-gray-200">
            <th className="px-6 py-4 text-right font-semibold text-gray-900 w-1/4">
              ספק
            </th>
            <th className="px-6 py-4 text-right font-semibold text-gray-900 w-1/4">
              שרות
            </th>
            <th className="px-6 py-4 text-center font-semibold text-gray-900">
              עלות חודשית
            </th>
            <th className="px-6 py-4 text-center font-semibold text-gray-900">
              עלות 12 חודשים
            </th>
            <th className="px-6 py-4 text-center font-semibold text-gray-900">
              דירוג / אמינות
            </th>
            <th className="px-6 py-4 text-center font-semibold text-gray-900">
              פעולה
            </th>
          </tr>
        </thead>
        <tbody>
          {prices.map((price, idx) => (
            <tr
              key={price.vendorId + price.serviceId + idx}
              className={`border-b border-gray-200 hover:bg-blue-50 transition ${
                idx === 0 ? "bg-green-50" : ""
              }`}
            >
              {/* VENDOR */}
              <td className="px-6 py-4">
                <div className="flex items-center gap-2">
                  {idx === 0 && (
                    <span className="inline-block bg-green-500 text-white px-2 py-1 rounded text-xs font-bold">
                      הזול ביותר
                    </span>
                  )}
                  <div>
                    <p className="font-semibold text-gray-900">
                      {price.vendorName}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {price.review_count} ביקורות
                    </p>
                  </div>
                </div>
              </td>

              {/* SERVICE */}
              <td className="px-6 py-4">
                <p className="text-gray-900 font-medium">{price.serviceName}</p>
                {price.promo_period_months && (
                  <p className="text-xs text-orange-600 mt-1">
                    🎁 הצעה: {price.promo_period_months} חודשים
                  </p>
                )}
              </td>

              {/* MONTHLY COST */}
              <td className="px-6 py-4 text-center">
                <p className="font-semibold text-gray-900">
                  ₪{Math.round(price.monthly_cost)}
                </p>
                {price.one_time_cost > 0 && (
                  <p className="text-xs text-gray-500 mt-1">
                    + ₪{Math.round(price.one_time_cost)} התקנה
                  </p>
                )}
              </td>

              {/* 12-MONTH TOTAL */}
              <td className="px-6 py-4 text-center">
                <p className="text-lg font-bold text-blue-600">
                  ₪{Math.round(price.total_12_month_cost)}
                </p>
              </td>

              {/* RATING & TRUST */}
              <td className="px-6 py-4 text-center">
                <div className="flex flex-col items-center gap-1">
                  {/* Stars */}
                  <div className="flex gap-0.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <span
                        key={star}
                        className={
                          star <= (price.rating_avg || 0)
                            ? "text-yellow-400"
                            : "text-gray-300"
                        }
                      >
                        ★
                      </span>
                    ))}
                  </div>

                  {/* Confidence Badge */}
                  <span
                    className={`text-xs font-semibold px-2 py-1 rounded ${
                      price.confidence_score > 0.7
                        ? "bg-green-100 text-green-800"
                        : price.confidence_score > 0.5
                        ? "bg-yellow-100 text-yellow-800"
                        : "bg-red-100 text-red-800"
                    }`}
                  >
                    {price.confidence_score > 0.7
                      ? "✓ מאומת"
                      : price.confidence_score > 0.5
                      ? "⚠ בדיקה"
                      : "❌ לא בדוק"}
                  </span>

                  {/* Verification Type */}
                  <span className="text-xs text-gray-500 mt-1">
                    {price.verification_type === "CERTIFIED_VENDOR"
                      ? "מהספק"
                      : price.verification_type === "USER_REPORTED"
                      ? "מגולשים"
                      : "אוטומטי"}
                  </span>
                </div>
              </td>

              {/* ACTION */}
              <td className="px-6 py-4 text-center">
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium text-sm transition">
                  בדוק עכשיו
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
