// scripts/seed.ts
// Database seed with sample Israeli utility and service provider data

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...\n');

  try {
    // ========================================================================
    // 1. CREATE CATEGORIES
    // ========================================================================

    console.log('📂 Creating categories...');

    const cellular = await prisma.category.upsert({
      where: { type: 'CELLULAR' },
      update: {},
      create: {
        type: 'CELLULAR',
        name_he: 'סלולר',
        name_en: 'Cellular',
        description: 'חברות תקשורת סלולרית בישראל',
      },
    });

    const electricity = await prisma.category.upsert({
      where: { type: 'ELECTRICITY' },
      update: {},
      create: {
        type: 'ELECTRICITY',
        name_he: 'חשמל',
        name_en: 'Electricity',
        description: 'ספקי חשמל וחברות כוח',
      },
    });

    const internet = await prisma.category.upsert({
      where: { type: 'INTERNET' },
      update: {},
      create: {
        type: 'INTERNET',
        name_he: 'אינטרנט',
        name_en: 'Internet',
        description: 'חברות אינטרנט ובקו קבוע',
      },
    });

    const insurance = await prisma.category.upsert({
      where: { type: 'INSURANCE' },
      update: {},
      create: {
        type: 'INSURANCE',
        name_he: 'ביטוח רכב',
        name_en: 'Car Insurance',
        description: 'ביטוח רכב ותחזוקה',
      },
    });

    const carService = await prisma.category.upsert({
      where: { type: 'CAR_SERVICE' },
      update: {},
      create: {
        type: 'CAR_SERVICE',
        name_he: 'תיקוני רכב',
        name_en: 'Car Service',
        description: 'תיקוני רכב וגרגי טכנאים',
      },
    });

    console.log('✅ Categories created\n');

    // ========================================================================
    // 2. CREATE CELLULAR VENDORS
    // ========================================================================

    console.log('📱 Creating cellular vendors...');

    const partner = await prisma.vendor.upsert({
      where: { id: 'vendor-partner' },
      update: {},
      create: {
        id: 'vendor-partner',
        categoryId: cellular.id,
        name: 'Partner Communications',
        website: 'https://www.partner.co.il',
        phone: '1212',
        founded_year: 1990,
        rating_avg: 4.1,
        review_count: 542,
        is_primary_provider: true,
      },
    });

    const cellcom = await prisma.vendor.upsert({
      where: { id: 'vendor-cellcom' },
      update: {},
      create: {
        id: 'vendor-cellcom',
        categoryId: cellular.id,
        name: 'Cellcom',
        website: 'https://www.cellcom.co.il',
        phone: '1221',
        founded_year: 1994,
        rating_avg: 3.9,
        review_count: 628,
        is_primary_provider: true,
      },
    });

    const orange = await prisma.vendor.upsert({
      where: { id: 'vendor-orange' },
      update: {},
      create: {
        id: 'vendor-orange',
        categoryId: cellular.id,
        name: 'Orange/Hot Mobile',
        website: 'https://www.orange.co.il',
        phone: '1877',
        founded_year: 2002,
        rating_avg: 3.7,
        review_count: 456,
        is_primary_provider: true,
      },
    });

    const golan = await prisma.vendor.upsert({
      where: { id: 'vendor-golan' },
      update: {},
      create: {
        id: 'vendor-golan',
        categoryId: cellular.id,
        name: 'Golan Telecom',
        website: 'https://www.golan.co.il',
        phone: '1800',
        founded_year: 2005,
        rating_avg: 3.8,
        review_count: 234,
        is_primary_provider: false,
      },
    });

    console.log('✅ Cellular vendors created\n');

    // ========================================================================
    // 3. CREATE CELLULAR PLANS
    // ========================================================================

    console.log('📋 Creating cellular plans...');

    // Partner - Plan 1
    const partnerPlan1 = await prisma.service.upsert({
      where: { id: 'service-partner-10gb' },
      update: {},
      create: {
        id: 'service-partner-10gb',
        categoryId: cellular.id,
        vendorId: partner.id,
        name: 'Partner - 10GB 5G + Unlimited Calls',
        code: 'PARTNER_10GB',
        contract_length_months: 24,
      },
    });

    // Create price for Partner plan
    await prisma.price.upsert({
      where: { id: 'price-partner-10gb-1' },
      update: {},
      create: {
        id: 'price-partner-10gb-1',
        categoryId: cellular.id,
        vendorId: partner.id,
        serviceId: partnerPlan1.id,
        model: 'SUBSCRIPTION',
        base_price: 39.90,
        setup_fee: 0,
        promo_months: 3,
        promo_price: 29.90,
        monthly_recurring: 39.90,
        verification: 'CERTIFIED_VENDOR',
        status: 'VERIFIED',
        confidence_score: 0.95,
        is_active: true,
      },
    });

    // Cellcom - Plan 1
    const cellcomPlan1 = await prisma.service.upsert({
      where: { id: 'service-cellcom-15gb' },
      update: {},
      create: {
        id: 'service-cellcom-15gb',
        categoryId: cellular.id,
        vendorId: cellcom.id,
        name: 'Cellcom - 15GB 5G + Unlimited',
        code: 'CELLCOM_15GB',
        contract_length_months: 12,
      },
    });

    await prisma.price.upsert({
      where: { id: 'price-cellcom-15gb-1' },
      update: {},
      create: {
        id: 'price-cellcom-15gb-1',
        categoryId: cellular.id,
        vendorId: cellcom.id,
        serviceId: cellcomPlan1.id,
        model: 'SUBSCRIPTION',
        base_price: 44.90,
        setup_fee: 0,
        promo_months: 2,
        promo_price: 34.90,
        monthly_recurring: 44.90,
        verification: 'CERTIFIED_VENDOR',
        status: 'VERIFIED',
        confidence_score: 0.94,
        is_active: true,
      },
    });

    // Orange - Plan 1 (Budget option)
    const orangePlan1 = await prisma.service.upsert({
      where: { id: 'service-orange-8gb' },
      update: {},
      create: {
        id: 'service-orange-8gb',
        categoryId: cellular.id,
        vendorId: orange.id,
        name: 'Orange - 8GB + Unlimited',
        code: 'ORANGE_8GB',
        contract_length_months: 12,
      },
    });

    await prisma.price.upsert({
      where: { id: 'price-orange-8gb-1' },
      update: {},
      create: {
        id: 'price-orange-8gb-1',
        categoryId: cellular.id,
        vendorId: orange.id,
        serviceId: orangePlan1.id,
        model: 'SUBSCRIPTION',
        base_price: 34.90,
        setup_fee: 49.90, // Device subsidy/setup
        promo_months: 1,
        promo_price: 24.90,
        monthly_recurring: 34.90,
        verification: 'CERTIFIED_VENDOR',
        status: 'VERIFIED',
        confidence_score: 0.93,
        is_active: true,
      },
    });

    console.log('✅ Cellular plans created\n');

    // ========================================================================
    // 4. CREATE ELECTRICITY VENDOR
    // ========================================================================

    console.log('⚡ Creating electricity vendors...');

    const iec = await prisma.vendor.upsert({
      where: { id: 'vendor-iec' },
      update: {},
      create: {
        id: 'vendor-iec',
        categoryId: electricity.id,
        name: 'Israel Electric Company',
        website: 'https://www.iec.co.il',
        phone: '1800',
        rating_avg: 2.8,
        review_count: 3421,
        is_primary_provider: true,
      },
    });

    // Electricity plan (tiered pricing)
    const elecPlan = await prisma.service.upsert({
      where: { id: 'service-iec-standard' },
      update: {},
      create: {
        id: 'service-iec-standard',
        categoryId: electricity.id,
        vendorId: iec.id,
        name: 'Standard Residential Rate',
        code: 'IEC_STD',
      },
    });

    await prisma.price.upsert({
      where: { id: 'price-iec-standard-1' },
      update: {},
      create: {
        id: 'price-iec-standard-1',
        categoryId: electricity.id,
        vendorId: iec.id,
        serviceId: elecPlan.id,
        model: 'TIERED',
        base_price: 0.47, // First tier rate
        setup_fee: 50, // Monthly fixed fee
        verification: 'CERTIFIED_VENDOR',
        status: 'VERIFIED',
        confidence_score: 0.98,
        is_active: true,
      },
    });

    console.log('✅ Electricity vendors created\n');

    // ========================================================================
    // 5. CREATE CAR SERVICE VENDORS (Garages)
    // ========================================================================

    console.log('🔧 Creating car service vendors...');

    const garage1 = await prisma.vendor.upsert({
      where: { id: 'vendor-garage-tlv-1' },
      update: {},
      create: {
        id: 'vendor-garage-tlv-1',
        categoryId: carService.id,
        name: 'תיקוני זהב - גרג בתל אביב',
        address: 'רח\' ירמיהו 42',
        city: 'תל אביב',
        latitude: 32.0853,
        longitude: 34.7818,
        phone: '03-5555555',
        rating_avg: 4.6,
        review_count: 127,
        is_primary_provider: false,
      },
    });

    const garage2 = await prisma.vendor.upsert({
      where: { id: 'vendor-garage-haifa-1' },
      update: {},
      create: {
        id: 'vendor-garage-haifa-1',
        categoryId: carService.id,
        name: 'ערן טכנאים - חיפה',
        address: 'רח\' אבא הלל 12',
        city: 'חיפה',
        latitude: 32.8194,
        longitude: 35.0073,
        phone: '04-8888888',
        rating_avg: 4.3,
        review_count: 89,
        is_primary_provider: false,
      },
    });

    console.log('✅ Car service vendors created\n');

    // ========================================================================
    // 6. CREATE CAR SERVICES
    // ========================================================================

    console.log('🛠️  Creating car services...');

    const oilChange = await prisma.service.upsert({
      where: { id: 'service-oil-change' },
      update: {},
      create: {
        id: 'service-oil-change',
        categoryId: carService.id,
        name: 'Oil Change',
        code: 'OIL_CHG',
        mileage_min: 0,
        mileage_max: 100000,
      },
    });

    // Garage 1 - Oil change price
    await prisma.price.upsert({
      where: { id: 'price-garage1-oil-1' },
      update: {},
      create: {
        id: 'price-garage1-oil-1',
        categoryId: carService.id,
        vendorId: garage1.id,
        serviceId: oilChange.id,
        model: 'FIXED',
        base_price: 180,
        verification: 'USER_REPORTED',
        status: 'VERIFIED',
        confidence_score: 0.75,
        is_active: true,
      },
    });

    // Garage 2 - Oil change price
    await prisma.price.upsert({
      where: { id: 'price-garage2-oil-1' },
      update: {},
      create: {
        id: 'price-garage2-oil-1',
        categoryId: carService.id,
        vendorId: garage2.id,
        serviceId: oilChange.id,
        model: 'FIXED',
        base_price: 160,
        verification: 'USER_REPORTED',
        status: 'VERIFIED',
        confidence_score: 0.72,
        is_active: true,
      },
    });

    const brakeJob = await prisma.service.upsert({
      where: { id: 'service-brake-job' },
      update: {},
      create: {
        id: 'service-brake-job',
        categoryId: carService.id,
        name: 'Brake Pad Replacement',
        code: 'BRAKE_JOB',
      },
    });

    // Garage 1 - Brake job (range)
    await prisma.price.upsert({
      where: { id: 'price-garage1-brake-1' },
      update: {},
      create: {
        id: 'price-garage1-brake-1',
        categoryId: carService.id,
        vendorId: garage1.id,
        serviceId: brakeJob.id,
        model: 'RANGE',
        base_price: 350,
        price_min: 250,
        price_max: 450,
        verification: 'USER_REPORTED',
        status: 'VERIFIED',
        confidence_score: 0.68,
        is_active: true,
      },
    });

    console.log('✅ Car services created\n');

    // ========================================================================
    // 7. CREATE INSURANCE VENDORS
    // ========================================================================

    console.log('🛡️  Creating insurance vendors...');

    const harel = await prisma.vendor.upsert({
      where: { id: 'vendor-harel-insurance' },
      update: {},
      create: {
        id: 'vendor-harel-insurance',
        categoryId: insurance.id,
        name: 'Harel Insurance',
        website: 'https://www.harel.co.il',
        phone: '*3566',
        rating_avg: 3.9,
        review_count: 1200,
        is_primary_provider: true,
      },
    });

    const psagot = await prisma.vendor.upsert({
      where: { id: 'vendor-psagot-insurance' },
      update: {},
      create: {
        id: 'vendor-psagot-insurance',
        categoryId: insurance.id,
        name: 'Psagot Insurance',
        website: 'https://www.psagot.co.il',
        phone: '*1599',
        rating_avg: 4.0,
        review_count: 950,
        is_primary_provider: true,
      },
    });

    console.log('✅ Insurance vendors created\n');

    // ========================================================================
    // 8. CREATE INSURANCE PLANS
    // ========================================================================

    console.log('📋 Creating insurance plans...');

    const thirdPartyPlan = await prisma.service.upsert({
      where: { id: 'service-insurance-3rd-party' },
      update: {},
      create: {
        id: 'service-insurance-3rd-party',
        categoryId: insurance.id,
        name: 'Third Party Liability (חובה)',
        code: 'INS_3RD_PARTY',
      },
    });

    // Harel - Third party
    await prisma.price.upsert({
      where: { id: 'price-harel-3rd-1' },
      update: {},
      create: {
        id: 'price-harel-3rd-1',
        categoryId: insurance.id,
        vendorId: harel.id,
        serviceId: thirdPartyPlan.id,
        model: 'SUBSCRIPTION',
        base_price: 1200 / 12, // Annual ₪1200 → monthly
        setup_fee: 0,
        promo_months: 0,
        verification: 'CERTIFIED_VENDOR',
        status: 'VERIFIED',
        confidence_score: 0.96,
        is_active: true,
      },
    });

    // Psagot - Third party
    await prisma.price.upsert({
      where: { id: 'price-psagot-3rd-1' },
      update: {},
      create: {
        id: 'price-psagot-3rd-1',
        categoryId: insurance.id,
        vendorId: psagot.id,
        serviceId: thirdPartyPlan.id,
        model: 'SUBSCRIPTION',
        base_price: 1150 / 12,
        setup_fee: 0,
        promo_months: 0,
        verification: 'CERTIFIED_VENDOR',
        status: 'VERIFIED',
        confidence_score: 0.96,
        is_active: true,
      },
    });

    console.log('✅ Insurance plans created\n');

    // ========================================================================
    // SUMMARY
    // ========================================================================

    console.log('✨ Seed completed successfully!\n');
    console.log('📊 Summary:');
    console.log(`   ✓ ${5} categories`);
    console.log(`   ✓ ${7} vendors`);
    console.log(`   ✓ ${11} services`);
    console.log(`   ✓ ${16} price points`);
    console.log('\n🚀 Ready to search!\n');
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

main();
