# תאכלס - הכי זול בארץ

Israeli price comparison platform for utilities, insurance, and vehicle services.

## Tech Stack

- **Frontend**: Next.js 14, React, Tailwind CSS, Hebrew RTL
- **Backend**: Next.js API Routes, Prisma ORM
- **Database**: PostgreSQL
- **Cache**: Redis
- **Hosting**: Vercel

## Getting Started

### Local Development

```bash
npm install
npx prisma migrate dev
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Environment Variables

Create `.env.local`:

```
DATABASE_URL=postgresql://...
REDIS_URL=redis://...
JWT_SECRET=<random-string>
NEXTAUTH_SECRET=<random-string>
```

## Deployment

Deployed to Vercel. Push to `main` branch to auto-deploy.

## Features

- Price comparison for cellular, electricity, internet, gas, insurance, car services
- Geolocation-based search for local services
- Multiple pricing models: fixed, subscription, tiered, range-based
- User-reported prices with verification system
- Real-time price updates

## Categories

1. **סלולר** (Cellular) - Telecom plans
2. **חשמל** (Electricity) - Utility providers
3. **אינטרנט** (Internet) - Broadband ISPs
4. **ביטוח רכב** (Car Insurance) - Vehicle insurance
5. **תיקוני רכב** (Car Service) - Garages and mechanics
6. **גז** (Gas) - Fuel and heating

Made with ❤️ in Israel
