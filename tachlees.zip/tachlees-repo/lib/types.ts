// lib/types.ts
// Production TypeScript definitions for תאכלס price comparison platform

import type { Decimal } from "@prisma/client/runtime/library";

// ============================================================================
// ENUMS (matches Prisma)
// ============================================================================

export enum CategoryType {
  ELECTRICITY = "ELECTRICITY",
  CELLULAR = "CELLULAR",
  INTERNET = "INTERNET",
  GAS = "GAS",
  INSURANCE = "INSURANCE",
  CAR_SERVICE = "CAR_SERVICE",
}

export enum PricingModel {
  FIXED = "FIXED",
  TIERED = "TIERED",
  RANGE = "RANGE",
  SUBSCRIPTION = "SUBSCRIPTION",
  USAGE_BASED = "USAGE_BASED",
}

export enum VerificationType {
  AUTOMATED_SCRAPE = "AUTOMATED_SCRAPE",
  USER_REPORTED = "USER_REPORTED",
  CERTIFIED_VENDOR = "CERTIFIED_VENDOR",
}

export enum VerificationStatus {
  UNVERIFIED = "UNVERIFIED",
  PENDING = "PENDING",
  VERIFIED = "VERIFIED",
  FLAGGED = "FLAGGED",
  DEPRECATED = "DEPRECATED",
}

export enum VehicleCategory {
  CAR_SMALL = "CAR_SMALL",
  CAR_MEDIUM = "CAR_MEDIUM",
  CAR_LARGE = "CAR_LARGE",
  SUV_SMALL = "SUV_SMALL",
  SUV_LARGE = "SUV_LARGE",
  TRUCK = "TRUCK",
  VAN = "VAN",
}

export enum InsuranceType {
  THIRD_PARTY = "THIRD_PARTY",
  THIRD_PARTY_PLUS = "THIRD_PARTY_PLUS",
  COMPREHENSIVE = "COMPREHENSIVE",
}

// ============================================================================
// DOMAIN MODELS
// ============================================================================

export interface Category {
  id: string;
  type: CategoryType;
  name_he: string;
  name_en: string;
  description?: string;
  icon_url?: string;
}

export interface Vendor {
  id: string;
  categoryId: string;
  name: string;
  website?: string;
  phone?: string;
  email?: string;
  founded_year?: number;
  rating_avg: number;
  review_count: number;
  is_primary_provider: boolean;
  latitude?: number;
  longitude?: number;
  address?: string;
  city?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Service {
  id: string;
  categoryId: string;
  vendorId?: string;
  name: string;
  description?: string;
  code?: string;
  category_data?: Record<string, any>;
  contract_length_months?: number;
  setup_fee?: Decimal;
  mileage_min?: number;
  mileage_max?: number;
  vehicle_category?: VehicleCategory;
  createdAt: Date;
  updatedAt: Date;
}

export interface Price {
  id: string;
  categoryId: string;
  vendorId: string;
  serviceId: string;
  model: PricingModel;
  base_price: Decimal;
  currency: string;
  monthly_recurring?: Decimal;
  promo_months?: number;
  promo_price?: Decimal;
  price_min?: Decimal;
  price_max?: Decimal;
  unit_type?: string;
  verification: VerificationType;
  status: VerificationStatus;
  verified_by?: string;
  verified_at?: Date;
  confidence_score: number;
  branchId?: string;
  effective_from: Date;
  effective_to?: Date;
  is_active: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Branch {
  id: string;
  vendorId: string;
  name: string;
  address: string;
  city: string;
  latitude: number;
  longitude: number;
  phone?: string;
  hours?: string;
  createdAt: Date;
  updatedAt: Date;
}

// ============================================================================
// BUSINESS LOGIC TYPES
// ============================================================================

/**
 * Normalized price representation for comparison.
 * Converts all pricing models (subscription, fixed, range) to a common format.
 */
export interface NormalizedPrice {
  // Base
  vendorId: string;
  vendorName: string;
  serviceId: string;
  serviceName: string;
  
  // Pricing breakdown
  one_time_cost: number;      // Setup fee + equipment (₪)
  monthly_cost: number;       // Normalized to monthly (₪/month)
  total_12_month_cost: number; // one_time + (monthly_cost * 12)
  
  // Cost per unit (for comparison visibility)
  cost_per_unit?: number;     // e.g., ₪/kWh for electricity, ₪/GB for data
  
  // Validity & trust
  effective_from: Date;
  effective_to?: Date;
  verification_type: VerificationType;
  confidence_score: number;    // 0-1, impacts ranking
  
  // Metadata
  rating_avg?: number;
  review_count?: number;
  rating_from_this_service?: number; // Reviews specific to this price
  
  // Location (for local services)
  branch?: {
    id: string;
    name: string;
    address: string;
    distance_km?: number; // Computed from user location
  };
  
  // Promo details
  promo_period_months?: number;
  promo_ends_at?: Date;
}

/**
 * Price calculation engine - converts raw prices to comparable total costs
 */
export interface PriceCalculationInput {
  base_price: number;
  model: PricingModel;
  
  // Subscription-specific
  setup_fee?: number;
  monthly_recurring?: number;
  promo_months?: number;
  promo_price?: number;
  contract_length_months?: number;
  
  // Range-based
  price_min?: number;
  price_max?: number;
  
  // Usage-based (for electricity, internet)
  monthly_consumption?: number;  // kWh, GB, etc.
  tiered_rates?: TieredRate[];
}

export interface TieredRate {
  up_to_units: number;
  price_per_unit: number;
}

export interface PriceCalculationOutput {
  setup_cost: number;
  monthly_cost: number;
  total_12_month_cost: number;
  cost_per_unit?: number;
  
  // Breakdown
  breakdown: {
    setup: number;
    month_1_to_promo: number;  // If promo exists
    month_promo_plus_1_to_12: number;
    subsequent_months: number;
  };
}

/**
 * Search & filter request from client
 */
export interface PriceSearchRequest {
  // Category & Service
  category: CategoryType;
  service_query?: string;        // Free-text search
  
  // Location filter
  city?: string;
  latitude?: number;
  longitude?: number;
  radius_km?: number;             // For local services (garages)
  
  // Category-specific parameters
  params?: CategorySpecificParams;
  
  // Filtering
  verification_types?: VerificationType[];
  min_confidence_score?: number;
  exclude_flagged?: boolean;
  
  // Sorting
  sort_by?: "price_asc" | "price_desc" | "rating" | "distance" | "confidence";
  
  // Pagination
  limit?: number;
  offset?: number;
}

export interface CategorySpecificParams {
  // Cellular
  data_gb?: number;
  minutes_needed?: number;
  
  // Electricity
  monthly_kwh_consumption?: number;
  
  // Car Services
  vehicle_category?: VehicleCategory;
  mileage_km?: number;
  service_type?: string;           // "Oil change", "Brake job", etc.
  
  // Insurance
  insurance_type?: InsuranceType;
  vehicle_year?: number;
  driver_age?: number;
  has_claims?: boolean;
}

/**
 * Search results - paginated list of normalized prices
 */
export interface PriceSearchResponse {
  results: NormalizedPrice[];
  total_count: number;
  total_pages: number;
  current_page: number;
  
  // Metadata for UI
  metadata: {
    search_time_ms: number;
    average_price: number;
    median_price: number;
    price_range: {
      min: number;
      max: number;
    };
    top_vendor_by_rating?: string; // vendorId
    cheapest_vendor?: string;      // vendorId
  };
}

/**
 * Detailed vendor comparison (shows all their offerings)
 */
export interface VendorComparison {
  vendor: Vendor;
  services: {
    service: Service;
    prices: NormalizedPrice[];
    user_reviews: ReviewSummary;
  }[];
}

/**
 * Review aggregation
 */
export interface ReviewSummary {
  total_reviews: number;
  verified_reviews: number;
  average_rating: number;
  distribution: {
    stars_5: number;
    stars_4: number;
    stars_3: number;
    stars_2: number;
    stars_1: number;
  };
  recent_reviews: {
    reported_price: number;
    rating: number;
    comment?: string;
    created_at: Date;
  }[];
}

/**
 * Geolocation result for branch-based search
 */
export interface NearbyBranch extends Branch {
  distance_km: number;
  travel_time_minutes?: number; // Optional, for future integration
}

/**
 * Batch price calculation (for price engine)
 */
export interface BatchPriceCalculation {
  prices: PriceCalculationInput[];
}

// ============================================================================
// API RESPONSE TYPES
// ============================================================================

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: Record<string, any>;
  };
  timestamp: string;
  request_id: string;
}

export interface PaginationMeta {
  total: number;
  page: number;
  per_page: number;
  total_pages: number;
  has_next: boolean;
  has_prev: boolean;
}

// ============================================================================
// CACHING KEYS
// ============================================================================

export const CACHE_KEYS = {
  // Search results (vary by category, location, params)
  SEARCH: (category: string, params: string) =>
    `search:${category}:${params}`,
  
  // Vendor details
  VENDOR: (vendorId: string) => `vendor:${vendorId}`,
  
  // Service details
  SERVICE: (serviceId: string) => `service:${serviceId}`,
  
  // Price data
  PRICE: (priceId: string) => `price:${priceId}`,
  
  // Category metadata
  CATEGORY: (categoryType: string) => `category:${categoryType}`,
  
  // Nearby branches (geo-indexed)
  BRANCHES_NEARBY: (lat: number, lng: number, radius: number) =>
    `branches:${lat}:${lng}:${radius}`,
  
  // Popular searches (for trending)
  TRENDING_SEARCHES: () => "trending:searches",
} as const;

export const CACHE_TTL = {
  SEARCH_RESULTS: 5 * 60,        // 5 minutes (frequent changes)
  PRICE_DATA: 15 * 60,            // 15 minutes
  VENDOR_PROFILE: 60 * 60,        // 1 hour
  CATEGORY_META: 24 * 60 * 60,   // 24 hours
  GEOLOCATION: 10 * 60,           // 10 minutes (user location)
} as const;

// ============================================================================
// ERROR TYPES
// ============================================================================

export class TachleesError extends Error {
  constructor(
    public code: string,
    message: string,
    public statusCode: number = 400,
    public details?: Record<string, any>
  ) {
    super(message);
    this.name = "TachleesError";
  }
}

export class ValidationError extends TachleesError {
  constructor(message: string, details?: Record<string, any>) {
    super("VALIDATION_ERROR", message, 400, details);
  }
}

export class NotFoundError extends TachleesError {
  constructor(resource: string, id?: string) {
    super(
      "NOT_FOUND",
      `${resource}${id ? ` (${id})` : ""} not found`,
      404
    );
  }
}

export class UnauthorizedError extends TachleesError {
  constructor(message = "Unauthorized") {
    super("UNAUTHORIZED", message, 401);
  }
}
