// lib/engines/price-engine.ts
// Production-grade price calculation and normalization

import type {
  PriceCalculationInput,
  PriceCalculationOutput,
  NormalizedPrice,
  TieredRate,
  Price as PriceModel,
  Vendor,
  Service,
} from "@/lib/types";
import { PricingModel, VerificationType } from "@/lib/types";

/**
 * Core Price Engine
 * Converts heterogeneous pricing models to comparable monthly/yearly costs
 */
export class PriceEngine {
  /**
   * Calculate total cost for any pricing model
   * Normalizes to 12-month horizon for fair comparison
   */
  static calculatePrice(input: PriceCalculationInput): PriceCalculationOutput {
    switch (input.model) {
      case PricingModel.FIXED:
        return this.calculateFixed(input);
      case PricingModel.SUBSCRIPTION:
        return this.calculateSubscription(input);
      case PricingModel.RANGE:
        return this.calculateRange(input);
      case PricingModel.TIERED:
        return this.calculateTiered(input);
      case PricingModel.USAGE_BASED:
        return this.calculateUsageBased(input);
      default:
        throw new Error(`Unknown pricing model: ${input.model}`);
    }
  }

  /**
   * Fixed pricing (e.g., "Oil change = ₪150")
   * Applies once, no recurring cost
   */
  private static calculateFixed(input: PriceCalculationInput): PriceCalculationOutput {
    const setup_cost = Number(input.base_price) || 0;

    return {
      setup_cost,
      monthly_cost: 0,
      total_12_month_cost: setup_cost,
      breakdown: {
        setup: setup_cost,
        month_1_to_promo: 0,
        month_promo_plus_1_to_12: 0,
        subsequent_months: 0,
      },
    };
  }

  /**
   * Subscription pricing with potential setup fees and promo periods
   * Common for: Cellular, Internet, Electricity (in some cases)
   *
   * Example: Cellular plan
   * - Setup fee: ₪0 (SIM card)
   * - Promo: First 3 months at ₪29.90
   * - Regular: ₪39.90/month thereafter
   * - Total 12-month: 0 + (29.90 * 3) + (39.90 * 9) = ₪449.70
   */
  private static calculateSubscription(
    input: PriceCalculationInput
  ): PriceCalculationOutput {
    const setup_fee = input.setup_fee ? Number(input.setup_fee) : 0;

    const promo_months = input.promo_months ?? 0;
    const promo_price = input.promo_price
      ? Number(input.promo_price)
      : Number(input.base_price);
    const regular_price = input.monthly_recurring
      ? Number(input.monthly_recurring)
      : Number(input.base_price);

    // Ensure we don't go beyond 12 months
    const actual_promo_months = Math.min(promo_months, 12);
    const regular_months = 12 - actual_promo_months;

    const promo_cost = promo_price * actual_promo_months;
    const regular_cost = regular_price * regular_months;

    // Average monthly (for sorting/display)
    const total_12_month = setup_fee + promo_cost + regular_cost;
    const monthly_cost = total_12_month / 12;

    return {
      setup_cost: setup_fee,
      monthly_cost,
      total_12_month_cost: total_12_month,
      breakdown: {
        setup: setup_fee,
        month_1_to_promo: promo_cost,
        month_promo_plus_1_to_12: regular_cost,
        subsequent_months: regular_price,
      },
    };
  }

  /**
   * Range pricing (min-max uncertainty)
   * Common for: Car repairs, garage services
   * 
   * Strategy: Use midpoint for sorting, but display range in UI
   * Example: "Brake job: ₪200-500" → average = ₪350
   */
  private static calculateRange(input: PriceCalculationInput): PriceCalculationOutput {
    const price_min = input.price_min ? Number(input.price_min) : Number(input.base_price);
    const price_max = input.price_max ? Number(input.price_max) : Number(input.base_price);

    const midpoint = (price_min + price_max) / 2;

    return {
      setup_cost: midpoint,
      monthly_cost: 0,
      total_12_month_cost: midpoint,
      breakdown: {
        setup: midpoint,
        month_1_to_promo: 0,
        month_promo_plus_1_to_12: 0,
        subsequent_months: 0,
      },
    };
  }

  /**
   * Tiered/stepped pricing
   * Common for: Electricity (different rates per consumption bracket)
   * 
   * Example: Electricity
   * - First 100 kWh: ₪0.50/kWh
   * - Next 50 kWh: ₪0.70/kWh
   * - Above 150 kWh: ₪0.85/kWh
   * 
   * If user consumes 200 kWh:
   * (100 × 0.50) + (50 × 0.70) + (50 × 0.85) = ₪117.50
   */
  private static calculateTiered(input: PriceCalculationInput): PriceCalculationOutput {
    if (!input.tiered_rates || input.tiered_rates.length === 0) {
      return this.calculateFixed(input);
    }

    if (!input.monthly_consumption) {
      // No consumption data, use first tier
      const first_rate = input.tiered_rates[0];
      const estimated_cost = first_rate.price_per_unit * 100; // Assume 100 units
      return {
        setup_cost: 0,
        monthly_cost: estimated_cost,
        total_12_month_cost: estimated_cost * 12,
        cost_per_unit: first_rate.price_per_unit,
        breakdown: {
          setup: 0,
          month_1_to_promo: estimated_cost * 12,
          month_promo_plus_1_to_12: 0,
          subsequent_months: estimated_cost,
        },
      };
    }

    let remaining_units = input.monthly_consumption;
    let total_cost = 0;

    // Sort tiers by threshold
    const sorted_tiers = [...input.tiered_rates].sort(
      (a, b) => a.up_to_units - b.up_to_units
    );

    for (let i = 0; i < sorted_tiers.length; i++) {
      const current_tier = sorted_tiers[i];
      const next_tier = sorted_tiers[i + 1];
      const tier_limit = next_tier ? next_tier.up_to_units - current_tier.up_to_units : Infinity;

      const units_in_tier = Math.min(remaining_units, tier_limit);
      total_cost += units_in_tier * current_tier.price_per_unit;
      remaining_units -= units_in_tier;

      if (remaining_units <= 0) break;
    }

    const monthly_cost = total_cost;

    return {
      setup_cost: 0,
      monthly_cost,
      total_12_month_cost: monthly_cost * 12,
      cost_per_unit: monthly_cost / input.monthly_consumption,
      breakdown: {
        setup: 0,
        month_1_to_promo: monthly_cost * 12,
        month_promo_plus_1_to_12: 0,
        subsequent_months: monthly_cost,
      },
    };
  }

  /**
   * Usage-based pricing (similar to tiered, but simpler)
   * Common for: Pay-per-GB internet, pay-per-minute calls
   */
  private static calculateUsageBased(input: PriceCalculationInput): PriceCalculationOutput {
    const monthly_consumption = input.monthly_consumption ?? 0;
    const cost_per_unit = Number(input.base_price);
    const monthly_cost = monthly_consumption * cost_per_unit;

    return {
      setup_cost: 0,
      monthly_cost,
      total_12_month_cost: monthly_cost * 12,
      cost_per_unit,
      breakdown: {
        setup: 0,
        month_1_to_promo: monthly_cost * 12,
        month_promo_plus_1_to_12: 0,
        subsequent_months: monthly_cost,
      },
    };
  }

  /**
   * Normalize a raw Price record + related entities into comparable format
   */
  static async normalizePrice(
    price: PriceModel,
    vendor: Vendor,
    service: Service,
    options?: {
      user_location?: { lat: number; lng: number };
      monthly_consumption?: number;
      vehicle_category?: string;
    }
  ): Promise<NormalizedPrice> {
    // Calculate cost breakdown
    const calculation = this.calculatePrice({
      base_price: Number(price.base_price),
      model: price.model,
      setup_fee: price.setup_fee ? Number(price.setup_fee) : undefined,
      monthly_recurring: price.monthly_recurring ? Number(price.monthly_recurring) : undefined,
      promo_months: price.promo_months,
      promo_price: price.promo_price ? Number(price.promo_price) : undefined,
      price_min: price.price_min ? Number(price.price_min) : undefined,
      price_max: price.price_max ? Number(price.price_max) : undefined,
      monthly_consumption: options?.monthly_consumption,
    });

    // Calculate confidence score based on verification type & recency
    const confidence_score = this.calculateConfidenceScore(price);

    // Determine promo end date if applicable
    let promo_ends_at: Date | undefined;
    if (price.promo_months && price.promo_months > 0) {
      promo_ends_at = new Date(price.effective_from);
      promo_ends_at.setMonth(promo_ends_at.getMonth() + price.promo_months);
    }

    const normalized: NormalizedPrice = {
      vendorId: vendor.id,
      vendorName: vendor.name,
      serviceId: service.id,
      serviceName: service.name,
      
      one_time_cost: calculation.setup_cost,
      monthly_cost: calculation.monthly_cost,
      total_12_month_cost: calculation.total_12_month_cost,
      cost_per_unit: calculation.cost_per_unit,
      
      effective_from: price.effective_from,
      effective_to: price.effective_to,
      verification_type: price.verification,
      confidence_score,
      
      rating_avg: vendor.rating_avg,
      review_count: vendor.review_count,
      
      promo_period_months: price.promo_months,
      promo_ends_at,
    };

    return normalized;
  }

  /**
   * Confidence score calculation
   * 0-1 scale: impacts sorting & display
   */
  private static calculateConfidenceScore(price: PriceModel): number {
    let score = 0.5; // Start at 0.5 (medium)

    // Verification type impact (+0.3)
    if (price.verification === VerificationType.CERTIFIED_VENDOR) {
      score += 0.3;
    } else if (price.verification === VerificationType.USER_REPORTED) {
      score += 0.1;
    } else {
      score += 0.05; // Automated scrape
    }

    // Status impact
    if (price.status === "VERIFIED") {
      score += 0.1;
    } else if (price.status === "FLAGGED") {
      score -= 0.2;
    }

    // Age impact (older = lower confidence)
    const days_old = Math.floor(
      (Date.now() - price.updated_at.getTime()) / (1000 * 60 * 60 * 24)
    );
    if (days_old < 7) {
      // Very recent
    } else if (days_old < 30) {
      score -= 0.05;
    } else if (days_old < 90) {
      score -= 0.15;
    } else {
      score -= 0.25;
    }

    // Clamp to 0-1
    return Math.max(0, Math.min(1, score));
  }

  /**
   * Sort prices by cheapest + confidence
   * Ranking formula: (total_12_month * confidence_factor) + confidence_bonus
   */
  static rankPrices(prices: NormalizedPrice[]): NormalizedPrice[] {
    const scored = prices.map((p) => {
      // Weighted score: prioritize price, but boost high-confidence items
      const base_score = p.total_12_month_cost;
      const confidence_multiplier = 1 - p.confidence_score * 0.15; // -15% boost for high confidence
      const weighted_score = base_score * confidence_multiplier;

      return { price: p, score: weighted_score };
    });

    scored.sort((a, b) => a.score - b.score);
    return scored.map((s) => s.price);
  }

  /**
   * Group prices by vendor for comparison UI
   */
  static groupByVendor(
    prices: NormalizedPrice[]
  ): Map<string, NormalizedPrice[]> {
    const grouped = new Map<string, NormalizedPrice[]>();

    for (const price of prices) {
      if (!grouped.has(price.vendorId)) {
        grouped.set(price.vendorId, []);
      }
      grouped.get(price.vendorId)!.push(price);
    }

    return grouped;
  }
}

/**
 * Helper: Calculate distance between two coordinates (haversine formula)
 * Used for local service search radius
 */
export function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
