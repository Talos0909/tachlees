// app/layout.tsx
// Layout ראשי עם תמיכה עברית RTL

import type { Metadata } from 'next';
import { Providers } from './providers';
import '@/styles/globals.css';

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'),
  title: 'תאכלס - הכי זול בארץ',
  description: 'השווה מחירים של סלולר, חשמל, אינטרנט וביטוח רכב בישראל',
  keywords: ['תאכלס', 'השוואת מחירים', 'סלולר', 'חשמל', 'אינטרנט', 'ביטוח', 'רכב'],
  openGraph: {
    title: 'תאכלס - הכי זול בארץ',
    description: 'מצא את המחיר הזול ביותר לכל שירות בישראל',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'תאכלס - הכי זול בארץ',
    description: 'מצא את המחיר הזול ביותר לכל שירות בישראל',
  },
  manifest: '/manifest.json',
  icons: {
    icon: '/favicon.ico',
    apple: '/apple-touch-icon.png',
  },
  other: {
    'facebook-domain-verification': 'your-verification-code',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="he" dir="rtl" className="scroll-smooth">
      <head>
        {/* תמיכה בעברית */}
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#0284c7" />
        
        {/* גופנים */}
        <link
          href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      
      <body
        className="bg-white text-gray-900 antialiased"
        style={{ fontFamily: '"Rubik", sans-serif' }}
      >
        <Providers>
          {/* Header */}
          <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="text-2xl font-bold text-blue-600">💰</div>
                  <h1 className="text-xl font-bold text-gray-900">
                    תאכלס
                  </h1>
                  <span className="text-xs font-medium text-gray-500">
                    הכי זול בארץ
                  </span>
                </div>
                
                <nav className="flex items-center gap-6">
                  <a
                    href="#"
                    className="text-sm font-medium text-gray-600 hover:text-gray-900 transition"
                  >
                    אודות
                  </a>
                  <a
                    href="#"
                    className="text-sm font-medium text-gray-600 hover:text-gray-900 transition"
                  >
                    צור קשר
                  </a>
                  <a
                    href="#"
                    className="text-sm font-medium text-gray-600 hover:text-gray-900 transition"
                  >
                    עזרה
                  </a>
                </nav>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1">
            {children}
          </main>

          {/* Footer */}
          <footer className="bg-gray-900 text-white mt-12">
            <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                {/* אודות */}
                <div>
                  <h3 className="text-lg font-bold mb-4">תאכלס</h3>
                  <p className="text-gray-400 text-sm">
                    משווה מחירים לסלולר, חשמל, אינטרנט, גז וביטוח רכב בישראל.
                    מוקד על המחיר הזול ביותר - בלי סחבה.
                  </p>
                </div>

                {/* קישורים */}
                <div>
                  <h4 className="text-sm font-bold mb-4">קישורים</h4>
                  <ul className="space-y-2 text-gray-400 text-sm">
                    <li><a href="#" className="hover:text-white transition">הבית</a></li>
                    <li><a href="#" className="hover:text-white transition">סלולר</a></li>
                    <li><a href="#" className="hover:text-white transition">חשמל</a></li>
                    <li><a href="#" className="hover:text-white transition">ביטוח</a></li>
                  </ul>
                </div>

                {/* תקשור */}
                <div>
                  <h4 className="text-sm font-bold mb-4">תקשור</h4>
                  <ul className="space-y-2 text-gray-400 text-sm">
                    <li><a href="mailto:info@tachlees.io" className="hover:text-white transition">info@tachlees.io</a></li>
                    <li><a href="#" className="hover:text-white transition">פייסבוק</a></li>
                    <li><a href="#" className="hover:text-white transition">טוויטר/X</a></li>
                    <li><a href="#" className="hover:text-white transition">WhatsApp</a></li>
                  </ul>
                </div>
              </div>

              {/* Copyright */}
              <div className="border-t border-gray-800 pt-8">
                <p className="text-gray-400 text-sm text-center">
                  © 2024 תאכלס - הכי זול בארץ. כל הזכויות שמורות.
                </p>
                <p className="text-gray-500 text-xs text-center mt-2">
                  עשוי בחביבות ❤️ בישראל | v1.0.0
                </p>
              </div>
            </div>
          </footer>
        </Providers>
      </body>
    </html>
  );
}
