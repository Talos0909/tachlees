// app/page.tsx
// דף הבית של תאכלס

import { PriceComparison } from '@/components/PriceComparison';
import { CategoryType } from '@/lib/types';

export default function Home() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-blue-50 to-transparent py-8 sm:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            תאכלס - הכי זול בארץ
          </h1>
          <p className="text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto mb-2">
            השווה מחירים של סלולר, חשמל, אינטרנט, גז וביטוח רכב
          </p>
          <p className="text-base text-gray-500 max-w-2xl mx-auto">
            מצא תמיד את המחיר הזול ביותר - ללא סחבה או הסתרים
          </p>
        </div>
      </section>

      {/* Main Search Component */}
      <PriceComparison defaultCategory={CategoryType.CELLULAR} />

      {/* Features Section */}
      <section className="bg-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            למה לבחור בתאכלס?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="flex flex-col items-center text-center">
              <div className="text-4xl mb-4">💰</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                המחיר הזול ביותר
              </h3>
              <p className="text-gray-600">
                אנחנו משווים את כל הספקים כדי שתקבל תמיד את ההצעה הזולה ביותר
              </p>
            </div>

            {/* Feature 2 */}
            <div className="flex flex-col items-center text-center">
              <div className="text-4xl mb-4">✓</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                מחירים מאומתים
              </h3>
              <p className="text-gray-600">
                כל המחירים מאומתים ישירות מהספקים, ללא הסתרים
              </p>
            </div>

            {/* Feature 3 */}
            <div className="flex flex-col items-center text-center">
              <div className="text-4xl mb-4">⚡</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                עדכנים בזמן אמת
              </h3>
              <p className="text-gray-600">
                המחירים מעודכנים כל יום, אז תמיד קבל את ההצעה החדשה ביותר
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-gray-50 py-12 sm:py-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            שאלות נפוצות
          </h2>
          
          <div className="space-y-6">
            {/* Q1 */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                איך תאכלס מוצא את המחיר הזול ביותר?
              </h3>
              <p className="text-gray-600">
                אנחנו קוספים מידע מישירות מהספקים וממשתמשים שלנו. כל מחיר אומת על ידי מערכת בדיקה שלנו.
              </p>
            </div>

            {/* Q2 */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                האם המחירים כוללים כל הדמי נסתרים?
              </h3>
              <p className="text-gray-600">
                כן! אנחנו מחזיקים בנוהל של "אפס דמים נסתרים". כל דמי התקנה, ציוד והזמנה כלולים בחישוב המחיר הסופי.
              </p>
            </div>

            {/* Q3 */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                איך אני יכול לדווח על טעות מחיר?
              </h3>
              <p className="text-gray-600">
                אם מצאת חיסרון במחיר, אתה יכול לדווח עליו ישירות בעמוד התוצאות. דוחות משתמשים עוזרים לנו לשמור על הנתונים מדוקדקים.
              </p>
            </div>

            {/* Q4 */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                כמה זמן זה לוקח לעדכן מחירים?
              </h3>
              <p className="text-gray-600">
                המחירים מעודכנים בצורה יומית מהספקים. משימות חיפוש של משתמשים מתעדכנות בתוך 24 שעות.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 text-white py-12 sm:py-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">
            מוכן לחסוך כסף?
          </h2>
          <p className="text-lg mb-8 opacity-90">
            התחל בחיפוש עכשיו ותמצא את ההצעה הטובה ביותר בשניות
          </p>
          <a
            href="#search"
            className="inline-block bg-white text-blue-600 px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition"
          >
            חפש עכשיו
          </a>
        </div>
      </section>
    </>
  );
}
